import { useEffect, useState } from 'react';
import Header from './components/Header';
import ProductList from './components/ProductList';
import ProductDetail from './components/ProductDetail';

function App() {
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);

  useEffect(() => {
    fetch('https://dummyjson.com/products')
      .then(res => res.json())
      .then(data => setProducts(data.products))
      .catch(err => console.error('Error fetching data:', err));
  }, []);

  return (
    <div>
      <Header />
      <div style={{ display: 'flex' }}>
        <ProductList products={products} onSelect={setSelectedProduct} />
        <ProductDetail product={selectedProduct} />
      </div>
    </div>
  );
}

export default App;
