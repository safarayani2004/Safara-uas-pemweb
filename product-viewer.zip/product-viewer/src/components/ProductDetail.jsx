const ProductDetail = ({ product }) => {
  if (!product) {
    return (
      <div style={{ padding: '1rem', width: '60%' }}>
        <h2>Detail Produk</h2>
        <p>Klik salah satu produk untuk melihat detailnya.</p>
      </div>
    );
  }

  return (
    <div style={{ padding: '1rem', width: '60%' }}>
      <h2>{product.title}</h2>
      <img
        src={product.thumbnail}
        alt={product.title}
        style={{ width: '100%', maxHeight: '300px', objectFit: 'cover' }}
      />
      <p><strong>Brand:</strong> {product.brand}</p>
      <p><strong>Price:</strong> ${product.price}</p>
      <p>{product.description}</p>
    </div>
  );
};

export default ProductDetail;
