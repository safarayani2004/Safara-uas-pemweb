const ProductList = ({ products, onSelect }) => {
  return (
    <div style={{ width: '40%', borderRight: '1px solid #ccc', padding: '1rem' }}>
      <h2>Products</h2>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {products.map(product => (
          <li
            key={product.id}
            style={{ marginBottom: '1rem', cursor: 'pointer' }}
            onClick={() => onSelect(product)}
          >
            <strong>{product.title}</strong>
            <p style={{ fontSize: '0.9rem' }}>{product.brand}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ProductList;
